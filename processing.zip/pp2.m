%% after pp1 loading 'smoothing3.mat'

clear;clc;

path2 = cd; 

load smoothing3;

min_d = 20;
min_d2 = 400;
flag = 0;
%% shape define############################################################
% shape = 0  -> not sorted
% shape = 1  -> flat 



shape = zeros(1,length(database1));

%% ########################################################################


for idx = 1:length(database1)

[aa,~] = findchangepts(f_point2(idx,:),'Statistic','linear','MinThreshold',min_d2);
x = f_point2(idx,:);

intvls = [1 aa length(f_point2(idx,:))];
clear interval_means;
interval_means = f_point2(idx,intvls);
L00 = length(interval_means);

if L00 < 3 % 완전 평평 
dumdum = (interval_means(1) + interval_means(2))/2;
interval_means = [interval_means(1),dumdum,interval_means(2)];
intvls = [1, 128, 256];
flag = 1;
end

% 1. Find peak
% a: value/ b: loc/ c: width/ d: prominence 
[a1,b1,c1,d1] = findpeaks(interval_means,intvls,'MinPeakProminence',min_d,'Annotate','extents');
[a2,b2,c2,d2] = findpeaks(-1*interval_means,intvls,'MinPeakProminence',min_d,'Annotate','extents');



% 2. Chirp rate   26206
devi=interval_means(2:end)-interval_means(1:end-1);

t0t0t0 = database1(idx).time;
t1t1t1 = (1:1:256)/256*max(t0t0t0);
intvv3 = t1t1t1(intvls);
intvv = intvv3(2:end)-intvv3(1:end-1);

devi2 = devi.*intvv;
devi22 = devi./intvv;
intvv2 = 1:1:256;
devi5 = ones(1,256);
devi52 = ones(1,256);

for idx2 = 1:length(intvls) - 1
  devi5(intvls(idx2):intvls(idx2+1)) = devi2(idx2);
  devi52(intvls(idx2):intvls(idx2+1)) = devi22(idx2);
end

% 3. Frequency gap
 gap1 = max(x) - min(x); 

% 4. flat part
    cr_nor = devi5;
    cr_nor2 = floor(abs(cr_nor)*2).*sign(cr_nor); 
    z = find(cr_nor2 == 0);
    stp = min(z);
    endp = max(z);
    clear fp1;

    if length(z) > 2
      z1 = z(2:end) - z(1:end-1);
      z2 = find(z1 > 1);

      if isempty(z2)
         fp1 = [min(z),max(z)];
      else
        fp1(1,:) = [stp, z(z2(1))];   
          for idx3 = 1:length(z2)-1
          fp1(idx3+1,:) = [ z(z2(idx3)+1),z(z2(idx3+1))];
          end
          fp1(length(z2)+1,:) = [ z(z2(end)+1),endp];
      end

     
     f_part= fp1;
     f_part_num = size(fp1,1);
     f_part_length = sum(fp1(:,2) - fp1(:,1));
    else
     f_part_num = NaN;
     f_part_length = NaN;
     f_part = NaN;
    end
    

% 5. Linear fitting coeff
    
f11p=fit(intvls',interval_means.','poly1');
coeffp1 = f11p.p1;
  

% 6. rapid part
    cr_nor = devi52;
    cr_nor2 = floor(abs(cr_nor)*2).*sign(cr_nor); 
    z = find(abs(cr_nor2) > 2*mean(cr_nor2));
    stp = min(z);
    endp = max(z);
    clear rp1;
    if length(z) > 2
      z1 = z(2:end) - z(1:end-1);
      z2 = find(z1 > 1);

      if isempty(z2)
         rp1 = [min(z),max(z)];
      else
        rp1(1,:) = [stp, z(z2(1))];   
          for idx3 = 1:length(z2)-1
          rp1(idx3+1,:) = [ z(z2(idx3)+1),z(z2(idx3+1))];
          end
          rp1(length(z2)+1,:) = [ z(z2(end)+1),endp];
      end

     
     r_part= rp1;
     r_part_num = size(rp1,1);
     r_part_length = sum(rp1(:,2) - rp1(:,1));
    else
     r_part_num = NaN;
     r_part_length = NaN;
     r_part = NaN;
    end

% 7. fitting

    freq_dum = f_point2(idx,:);
    x = t1t1t1;
    f9p=fit(x.',freq_dum.','poly9');

% Recording

history(idx).a1 = a1;
history(idx).a2 = a2;
history(idx).b1 = b1;
history(idx).b2 = b2;
history(idx).c1 = c1;
history(idx).c2 = c2;
history(idx).d1 = d1;
history(idx).d2 = d2;
history(idx).intvl = intvls;
history(idx).point = interval_means;
history(idx).cr_raw = devi5;
history(idx).cr_nor = devi52;
history(idx).gap = gap1;
history(idx).tt = intvv3;
history(idx).filename = database1(idx).filename;
history(idx).st_time = database1(idx).st;
history(idx).flag = flag;
history(idx).f_part_num = f_part_num;
history(idx).f_part_length = f_part_length;
history(idx).f_part = f_part;
history(idx).coef = coeffp1;
history(idx).r_part_num = r_part_num;
history(idx).r_part_length = r_part_length;
history(idx).r_part = r_part;
history(idx).fitting = f9p;
end




save([path2,'\processing\smoothing2.mat'],'history');








