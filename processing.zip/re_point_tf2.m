function [outputArg1,outputArg2] = re_point_tf2(time2,freq2,val)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here



%   time3 = [];
%   freq3 = [];
%  
  
% min_gap = min(time2(2:end) - time2(1:end-1));
time5 = 0:val:max(time2);
freq5(1) = freq2(1);

for idx = 2:length(time5)

   up_p = min(find(time5(idx) < time2));
   bottom_p = max(find(time2 < time5(idx)));

   up_t = time2(up_p);
   bottom_t = time2(bottom_p);

   up_f = freq2(up_p);
   bottom_f = freq2(bottom_p);


   a = (up_f-bottom_f)/(up_t-bottom_t);
   b = -1* (up_f-bottom_f)/(up_t-bottom_t)*bottom_t + bottom_f;

   freq5(idx) = a*time5(idx) + b;

end

% 
%   for idx2 = 1:length(time2)-1
%         time3_dum = time2(idx2):min_gap:time2(idx2+1);        
%         freq3_dum = interp1(time2(idx2:idx2+1),freq2(idx2:idx2+1),time3_dum,'linear');    
%         time3 = [time3,time3_dum];
%         freq3 = [freq3,freq3_dum];
%   end


outputArg1 = time5;
outputArg2 = freq5;



end