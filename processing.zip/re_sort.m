% clear;
% clc;
% 
% load d_id;
% 
% load('Database_Hoseo.mat')
% z_1 = Database.Whistle_Information;
% z_12 = fieldnames(Database.Whistle_Information);
% load('Database_Hoseo2.mat');
% z_2 = Database.Whistle_Information;
% z_22 = fieldnames(Database.Whistle_Information);
% 
% for idx = 1:length(d_id)
% if d_id(idx,1) == 1
% idx_0 = d_id(idx,2);
% z3 = getfield(z_1,{1},z_12{idx_0});
% database(idx).d = z3;
% elseif d_id(idx,1) == 2
% idx_0 = d_id(idx,2);
% z3 = getfield(z_2,{1},z_22{idx_0});
% database(idx).d = z3;
% end
% end
% 
% save('hoseo_total_p1.mat','database');
% 
% clc;
% clear;
% 
% load('Database_Hoseo_4차.mat');
% z_3 = Database.Whistle_Information;
% z_32 = fieldnames(Database.Whistle_Information);
% 
% for idx = 1:length(z_32)
% z3 = getfield(z_3,{1},z_32{idx});
% database(idx).d = z3;
% dum = z_32{idx};
% file_name{idx} = dum(6:end);
% end
% 
% save('hoseo_total_p2.mat','database');
% 
% 
% clc;
% clear;
% 
% load('Database_Inha_3차.mat');
% z_3 = Database.Whistle_Information;
% z_32 = fieldnames(Database.Whistle_Information);
% 
% for idx = 1:108
% z3 = getfield(z_3,{1},z_32{idx});
% database(idx).d = z3;
% dum = z_32{idx};
% file_name{idx} = dum(6:end);
% end
% 
% save('hoseo_total_p2.mat','database');

% clc;clear;
% 
% load('hoseo_total_p2.mat');
% 
% for idx = 1:62
% 
% z_3 = database(idx).d;
% z3 = z_3(1).filename;
% file_name{idx} = z3;
% end
% 
% % save('hoseo_total_p2.mat','database');


clc;clear;

load('INHA_p1.mat');

for idx = 1:108

z_3 = database(idx).d;
z3 = z_3(1).filename;
file_name{idx} = z3;
end

save('file_name.mat','file_name');