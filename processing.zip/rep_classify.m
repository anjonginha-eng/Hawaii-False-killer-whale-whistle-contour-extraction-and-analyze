clc;clear;close all


path2 = cd; 

load smoothing2.mat;

%% 1st shape define--------------------------------------------------------

for idx = 1:length(history)

    gap = history(idx).gap;
    gap2 = max(abs(gap));
    cr_nor = history(idx).cr_raw;
    cr_nor2 = max(abs(cr_nor));
    f_part_num = history(idx).f_part_num;
    f_part_length = history(idx).f_part_length;

    cr_nor3 = history(idx).cr_nor;
    rp_p = find(abs(cr_nor3) > 0.5e4);
    rp_p_l = length(rp_p);
    
              
    if ( (cr_nor2 < 10) && (gap2 < 300) && (f_part_length > 126) && (f_part_num == 1)&& (rp_p_l == 0))
        id3(idx) = 1000;
    else
        id3(idx) = 1;
    end


end


%% 
idx3 = 1;
for idx = 1:length(history)

tt0 = history(idx).tt;
tt=max(tt0);
point =  history(idx).point;
intvl = history(idx).intvl;
[f_max1 ,mp]=min(point);
mfp = intvl(mp);
[f_min1,mp]=max(point);
mxfp = intvl(mp);

shape_p = [0 0 0 0];
dumpp = [8 4 2 1];
if (intvl(1) == mxfp)
    shape_p(1) = 1;
end
if (intvl(1) == mfp)
    shape_p(2) = 1;
end

if (intvl(end) == mxfp)
    shape_p(3) = 1;
end
if (intvl(end) == mfp)
    shape_p(4) = 1;
end

shape_p2 = shape_p.*dumpp;
shape_p3 = sum(shape_p2);


flag = history(idx).flag;
a1 = history(idx).a1;
a2 = history(idx).a2;
L01 = length(a1)+ length(a2);         
gap = history(idx).gap;
    
 % prominence--------------------------------------------------------------
 coeffp1 = history(idx).coef;
 d1 = history(idx).d1;
 d2 = history(idx).d2;
 if isempty(d1)
     d1 = 0;
 end
 if isempty(d2)
     d2 = 0;
 end
 d0 = max([d1,d2]);
 d0min = min([d1,d2]);
 d0_2 = ([d1,d2]);
 d0_1 = d0_2(find(d0_2> 150));
 d0_3 = d0_2(find(d0_2> 300));
 d0_5 = d0_2(find(d0_2> 500));
 d0_7 = d0_2(find(d0_2> 700));
 d0_9 = d0_2(find(d0_2> 900));

 d1mx=max(d1);
 d2mx=max(d2);
 d12gap = abs(d1mx-d2mx);
 dtmean=(sum(d0_2)-d0)/(length(d0_2)-1);
 dtmean2=mean([d1,d2]);
 dmmgap = abs(d0-dtmean);


 d0_s = sort(d0_2,'ascend');
 dmmgap2 = d0_s(end) - d0_s(end-1);

 c_devi = d0/gap;

 % location----------------------------------------------------------------
 b1 = history(idx).b1;
 b2 = history(idx).b2;
 if isempty(b1)
     b1 = 0;
 end

 if isempty(b2)
     b2 = 0;
 end

 % bandwidth---------------------------------------------------------------
 c1 = history(idx).c1;
 c2 = history(idx).c2;
 if isempty(c1)
     c1 = 0;
 end

 if isempty(c2)
     c2 = 0;
 end
c0 = max([c1,c2]);

if (isempty(d1) == 1)&&(isempty(d2) == 0)
    up_down = 0;
elseif(isempty(d1) == 0)&&(isempty(d2) == 1)
    up_down = 1;
end

[~,d011] = max(d1);
[~,d022] = max(d2);

b11 = b1(d011);
b22 = b2(d022);

flag_b = 0;

 if b11>b22
     flag_b = 1;
 elseif b22>b11
     flag_b = 2;
 end

%--------------------------------------------------------------------------


    if ((L01 > 1) && (id3(idx) == 1)) 

%% Should check it is Line shape or not --> not concave
      if ((d0 < 70))

          if (gap < 300)
          id3(idx) = 1000;
          else
          id3(idx) = 7;
          end

      elseif((d0 < 100)&& (c_devi < 0.3) && (gap < 300))
          id3(idx) = 1000;
      elseif((d0 < 100)&& (c_devi > 0.3) && (c_devi <= 0.45) && (gap < 300))
          id3(idx) =  1000;
      elseif((d0 < 150)&& (c_devi > 0.45) && (c_devi <= 0.6) && (gap < 300))
          id3(idx) = 1000;
%--------------------------------------------------------------------------
      else
       
       if gap < 300 
           
         if (tt < 0.3)&&(d0 > 100)

                      if d12gap < 150 
                          if flag_b ==1
                            id3(idx) = 1002; % wave cos
                          elseif flag_b ==2
                            id3(idx) = 1003; % wave sin
                          end
                      else
                            id3(idx) = 4; % concave both
                      end
         else             
             id3(idx) = 1000; %% -->  flat line
         end

       elseif ((gap >= 300) && (gap < 600)) 

         if (tt < 0.3)&&(d0 > 150)

                      if d12gap < 100 
                          if flag_b ==1
                            id3(idx) = 1002; % wave cos
                          elseif flag_b ==2
                            id3(idx) = 1003; % wave sin
                          end
                      else
                            id3(idx) = 4; % concave both
                      end

         elseif ((tt >= 0.3)&&(tt < 0.6))&&(d0 > 200)

                      if (length(d0_1) <= 1) 
                            id3(idx) = 4; % concave both
                      elseif (length(d0_1) == 2) 
                          if flag_b ==1
                            id3(idx) = 1002; % wave cos
                          elseif flag_b ==2
                            id3(idx) = 1003; % wave sin 
                          end
                      else
                            id3(idx) = 0; % wave multi
                      end
         else             
             id3(idx) = 1000; %% -->  flat line
         end


       elseif ((gap >= 600) && (gap < 1000)) 

          if tt < 0.6
           if isempty(length(d0_1)) 
%                    id3(idx) = 2; % not exist
           elseif (length(d0_1) == 1) 
                   id3(idx) = 4; % concave
           elseif (length(d0_1) == 2) 

                if flag_b ==1
                   id3(idx) = 1002; % wave cos
                elseif flag_b ==2
                   id3(idx) = 1003; % wave sin 
                end

           elseif (length(d0_1) > 2) &&  ((d0 > 200)&&(tt < 0.6)) ||  ((d0 > 100)&&(tt < 0.3))

                if flag_b ==1
                   id3(idx) = 1002; % wave cos
                elseif flag_b ==2
                   id3(idx) = 1003; % wave sin 
                else
%                   id3(idx) = 6; % not exist
                end

           else
                  id3(idx) = 1000; % flat 
           end

         elseif ((tt >= 0.6)&&(tt < 0.9))

           if isempty(length(d0_1)) 
%                    id3(idx) = 2; % not exist
           elseif (length(d0_1) == 1) 
                   id3(idx) = 4; % concave
           elseif (length(d0_1) == 2) 

                if flag_b ==1
                   id3(idx) = 1002; % wave cos
                elseif flag_b ==2
                   id3(idx) = 1003; % wave sin 
                end

           elseif (length(d0_1) > 2) &&  ((d0 > 200)&&(tt < 0.8)) ||  ((d0 > 100)&&(tt < 0.7))
                  id3(idx) = 1002; % wave cos
           else
                  id3(idx) = 1000; % flat 
           end

         else
              id3(idx) = 1000; % flat line
         end

       elseif ((gap >= 1000)) 

         if tt < 0.3
              if (length(d0_1) <= 1) && (d0min <150) && (dtmean2 < 150) || ((d0min == dtmean2)&&(d0min<200))
                  id3(idx) = 7; % line
              else
                      if (d12gap < 300) && (d0min > 200)
                          if flag_b ==1
                            id3(idx) = 1002; % wave cos
                          elseif flag_b ==2
                            id3(idx) = 1003; % wave sin
                          end
                      elseif (length(d0_1) <= 1) && (d0min <150)|| ((d0min == dtmean2)&&(d0min<200))
                            id3(idx) = 4; % concave both
                      else
                          if flag_b ==1
                            id3(idx) = 1002; % wave cos
                          elseif flag_b ==2
                            id3(idx) = 1003; % wave sin
                          end
                      end
              end

         elseif ((tt >= 0.3)&&(tt < 0.6))
             if (length(d0_1) <= 2) && (d0min <200) && (dtmean2 < 200) ||  ((d0min == dtmean2)&&(d0min<500))
               id3(idx) = 7; % line
             else
                      if (d12gap < 400) && (d0min > 300)
                          if flag_b ==1
                            id3(idx) = 1002; % wave cos
                          elseif flag_b ==2
                            id3(idx) = 1003; % wave sin
                          end
                      elseif (length(d0_1) <= 2) && (d0min <260)|| ((d0min == dtmean2)&&(d0min<500))
                            id3(idx) = 4; % concave both
                      else
                          if flag_b ==1
                            id3(idx) = 1002; % wave cos
                          elseif flag_b ==2
                            id3(idx) = 1003; % wave sin
                          end
                      end
             end
         elseif (tt >= 0.6)
             if (length(d0_1) <= 2) && (d0min <300) && (dtmean2 < 250) || ((d0min == dtmean2)&&(d0min<500))
               id3(idx) = 7; % line
             else
                      if (d12gap < 400) && (d0min > 300)
                          if flag_b ==1
                            id3(idx) = 1002; % wave cos
                          elseif flag_b ==2
                            id3(idx) = 1003; % wave sin
                          end
                      elseif (length(d0_1) <= 2) && (d0min <260)|| ((d0min == dtmean2)&&(d0min<500))
                            id3(idx) = 4; % concave both
                      else
                          if flag_b ==1
                            id3(idx) = 1002; % wave cos
                          elseif flag_b ==2
                            id3(idx) = 1003; % wave sin
                          end
                      end
             end
         end

       end

      end





    end
    
end

%% ------------------------------------------------------------------------
for idx = 1:length(history)

flag = history(idx).flag;
a1 = history(idx).a1;
a2 = history(idx).a2;
L01 = length(a1)+ length(a2);         

gap = history(idx).gap;
    
coeffp1 = history(idx).coef;
cr_nor = history(idx).cr_nor;
[~,rp_max] = max(-1*cr_nor);
[~,rp_min] = min(-1*cr_nor);

cr_raw = history(idx).cr_raw;
rp_p = find(-1*(cr_nor) > 1e4);
rp_p_l = length(rp_p);
rp_var = var(cr_nor);



    if ((L01 == 0) && (id3(idx) == 1) && (coeffp1 < 0) && (gap > 300)  || ((id3(idx) == 7) && (coeffp1 < 0))) 

      if ((rp_max >= 128) && (rp_min <= 128) && (rp_p_l >= 16))
             id3(idx) = 2002;
     elseif ((rp_max <= 128) && (rp_min >= 128) && (rp_min <= 240) && (rp_p_l >= 1))
             id3(idx) = 2003;
      else
                        if (rp_var < 3e6)
%                                 if ((coeffp1 >= -2) && (coeffp1 < 0))
%                                    id3(idx) = 2004;
%                                 elseif ((coeffp1 >= -4) && (coeffp1 < -2))
%                                    id3(idx) = 2004;
%                                 else
%                                    id3(idx) = 2004;
%                                 end
                                   id3(idx) = 2004;
                        else
                                if ((rp_max >= 128) && (rp_min <= 128))
                                   id3(idx) = 2002;
                                elseif ((rp_max <= 128) && (rp_min >= 128) && (rp_min <= 240))
                                   id3(idx) = 2004;
                                else
                                    if ((rp_max >= 128) || (rp_min <= 128))
                                     id3(idx) =2003;
                                    elseif ((rp_max <= 128) || (rp_min >= 128))
                                     id3(idx) = 2003;
                                    else
%                                      id3(idx) = 2011; % empty
                                    end

                                end
                        end
      end
            
    end
    
end


%% ------------------------------------------------------------------------

for idx = 1:length(history)

flag = history(idx).flag;
a1 = history(idx).a1;
a2 = history(idx).a2;
L01 = length(a1)+ length(a2);       

gap = history(idx).gap;
    
coeffp1 = history(idx).coef;

intvls = history(idx).intvl;
point = history(idx).point;
mpm = min(find(intvls > 192));
mpm2 = point(mpm);
%% flat part 

f_part_length = history(idx).f_part_length;
f_part_num = history(idx).f_part_num;

cr_nor = history(idx).cr_nor;
[~,rp_max] = max(cr_nor);
[~,rp_min] = min(cr_nor);

cr_raw = history(idx).cr_raw;
rp_p = find((cr_raw) > 20);
rp_p_l = length(rp_p);

rp_p_min = min(rp_p);
rp_p_max = max(rp_p);

rp_num1 = history(idx).r_part_num;
rp_part = history(idx).r_part;

rp_p_max = max(max(rp_part));
rp_p_min = min(min(rp_part));

 d1 = history(idx).d1;
 d2 = history(idx).d2;
 d00 = max([d1,d2]);
 [mmmp ,mpp]=max(point);
 

gap3 = abs(mpm2 - mmmp);
    if ((L01 == 0) && (id3(idx) == 1) && (coeffp1 > 0) && (gap > 300) && (rp_num1 > 0) || ((id3(idx) == 7) && (coeffp1 > 0))) 

       if ((rp_max > 192)&&(rp_min < 64) && (rp_num1 == 1))
         id3(idx) = 3001;
       elseif ((rp_max < 64)&&(rp_min > 192)&& (rp_num1 == 1))
         id3(idx) =  3002;
       else
              if ((rp_max > 192))
                id3(idx) = 3001;
              else
                  if d00 < 128
                   id3(idx) =  3002;
                  else
                      if gap3 < 500
                   id3(idx) =  3002;
                      else
                   id3(idx) =  3001;
                      end
                  end
              end
       end

    elseif ((L01 == 0) && (id3(idx) == 1) && (coeffp1 > 0) && (gap > 300) && isnan(rp_num1)) 
%         if ((coeffp1 <= 5)&&(coeffp1 > 0))
%           id3(idx) =  3003;
%         elseif ((coeffp1 <= 15)&&(coeffp1 > 5))
%           id3(idx) =  3003;
%         else
%           id3(idx) =  3003;
%         end
          id3(idx) =  3003;
    end


end


%% ------------------------------------------------------------------------ 

for idx = 1:length(history)

point =  history(idx).point;
intvl = history(idx).intvl;
[~,mp]=min(point);
mfp = intvl(mp);
[~,mp]=max(point);
mxfp = intvl(mp);

flag = history(idx).flag;
a1 = history(idx).a1;
a2 = history(idx).a2;
L01 = length(a1)+ length(a2);      

gap = history(idx).gap;
    
 % prominence
 coeffp1 = history(idx).coef;
 d1 = history(idx).d1;
 d2 = history(idx).d2;
 d0 = max([d1,d2]);

 % location
 b1 = history(idx).b1;
 b2 = history(idx).b2;
 if isempty(b1)
     b1 = 0;
 end

 if isempty(b2)
     b2 = 0;
 end

 % bandwidth
 c1 = history(idx).c1;
 c2 = history(idx).c2;
 if isempty(c1)
     c1 = 0;
 end

 if isempty(c2)
     c2 = 0;
 end
c0 = max([c1,c2]);

if (isempty(d1) == 1)&&(isempty(d2) == 0)
    up_down = 0;
elseif(isempty(d1) == 0)&&(isempty(d2) == 1)
    up_down = 1;
else
    up_down = -1;
end

c_devi = d0/gap;

peak1 = (-1*a2 == min(point));
if isempty(max(d2))
ddd2 = -1;
else
ddd2 = max(d2);
end
if isempty(max(d1))
ddd1 = -1;
else
ddd1 = max(d1);
end
if  ddd1 > ddd2
    peak2 = 1; % ^ shape
else
    peak2 = 0; % u shape
end


    if (((L01 > 0) && (id3(idx) == 1)) || (id3(idx) == 4)) 

%% Should check it is Line shape or not --> not concave
      if ((d0 < 70))
      elseif((d0 < 100)&& (c_devi < 0.3) && (gap < 300))
      elseif((d0 < 100)&& (c_devi > 0.3) && (c_devi <= 0.45) && (gap < 300))
      elseif((d0 < 150)&& (c_devi > 0.45) && (c_devi <= 0.6) && (gap < 300))
%--------------------------------------------------------------------------
      else

          if (L01 == 1) || ((id3(idx) == 4)) % only 1 concave  up or down
                
               if (up_down == 0) || ((peak2) == 0) % concave down
                   % c0 : band widht/ d0 : prominenece
                   if (d0 < 200) 

                      if ((mfp <= 192)&&(mfp >= 64))
                       
                            if (c0 < 100)
                                if(mxfp <= 128)
                                 id3(idx) = 4002;   
                                else
                                 id3(idx) = 4003;   
                                end
                            elseif ((c0 >= 100) && (c0 < 200))
                              id3(idx) = 4004;                     
                            else
                              id3(idx) = 4005;             
                            end  

                      elseif (mfp <= 64)
                       id3(idx) = 4006;
                      else
                       id3(idx) = 4007;
                      end

                   elseif ((d0 >=200) &&  (d0 < 300))

                      if ((mfp <= 192)&&(mfp >= 64))
                       
                            if (c0 < 100)
                                if(mxfp <= 128)
                                 id3(idx) = 4002;   
                                else
                                 id3(idx) = 4003;   
                                end  
                            elseif ((c0 >= 100) && (c0 < 200))
                              id3(idx) = 4004;                     
                            else
                              id3(idx) = 4005;             
                            end  

                      elseif (mfp <= 64)
                       id3(idx) = 4006;
                      else
                       id3(idx) = 4007;
                      end

                   elseif ((d0 >=300) &&  (d0 < 400))

                      if ((mfp <= 192)&&(mfp >= 64))
                       
                            if (c0 < 100)
                                if(mxfp <= 128)
                                 id3(idx) = 4002;   
                                else
                                 id3(idx) = 4003;   
                                end
                            elseif ((c0 >= 100) && (c0 < 200))
                              id3(idx) = 4004;                     
                            else
                              id3(idx) = 4005;             
                            end  

                      elseif (mfp <= 64)
                       id3(idx) = 4006;
                      else
                       id3(idx) = 4007;
                      end

                   elseif ((d0 >=400))

                      if ((mfp <= 192)&&(mfp >= 64))
                       
                            if (c0 < 100)
                                if(mxfp <= 128)
                                 id3(idx) = 4002;   
                                else
                                 id3(idx) = 4003;   
                                end  
                            elseif ((c0 >= 100) && (c0 < 200))
                              id3(idx) = 4004;                     
                            else
                              id3(idx) = 4005;             
                            end  

                      elseif (mfp <= 64)
                       id3(idx) = 4006;
                      else
                       id3(idx) = 4007;
                      end


                   end
    
    
               end
    
    
           end
      end

    end
    
end

%% ------------------------------------------------------------------------
for idx = 1:length(history)
point =  history(idx).point;
intvl = history(idx).intvl;
[~,mp]=min(point);
mfp = intvl(mp);
[~,mp]=max(point);
mxfp = intvl(mp);

flag = history(idx).flag;
a1 = history(idx).a1;
a2 = history(idx).a2;
L01 = length(a1)+ length(a2);        

gap = history(idx).gap;
    
 % prominence
 coeffp1 = history(idx).coef;
 d1 = history(idx).d1;
 d2 = history(idx).d2;
 d0 = max([d1,d2]);

 % location
 b1 = history(idx).b1;
 b2 = history(idx).b2;
 if isempty(b1)
     b1 = 0;
 end

 if isempty(b2)
     b2 = 0;
 end

 % bandwidth
 c1 = history(idx).c1;
 c2 = history(idx).c2;
 if isempty(c1)
     c1 = 0;
 end

 if isempty(c2)
     c2 = 0;
 end
c0 = max([c1,c2]);

if (isempty(d1) == 1)&&(isempty(d2) == 0)
    up_down = 0;
elseif(isempty(d1) == 0)&&(isempty(d2) == 1)
    up_down = 1;
else
    up_down = -1;
end

c_devi = d0/gap;

peak1 = (a1 == max(point));

if isempty(max(d2))
ddd2 = -1;
else
ddd2 = max(d2);
end
if isempty(max(d1))
ddd1 = -1;
else
ddd1 = max(d1);
end
if  ddd1 > ddd2
    peak2 = 1; % ^ shape
else
    peak2 = 0; % u shape
end


    if (((L01 > 0) && (id3(idx) == 1)) || (id3(idx) == 4))

%% Should check it is Line shape or not --> not concave
      if ((d0 > 70))
          if (L01 == 1) || ((id3(idx) == 4) )% only 1 concave  up or down
                
               if (up_down == 1) || ((peak2) == 1)% concave down
                   % c0 : band widht/ d0 : prominenece
                   if (d0 < 200) 

                      if ((mxfp <= 192)&&(mxfp >= 64))
                       
                            if (c0 < 100)
                                if(mfp <= 128)
                                 id3(idx) = 5002;  
                                else
                                 id3(idx) = 5003;   
                                end
                            elseif ((c0 >= 100) && (c0 < 200))
                              id3(idx) = 5004;                     
                            else
                              id3(idx) = 5005;             
                            end  

                      elseif (mxfp <= 64)
                       id3(idx) = 5006;
                      else
                       id3(idx) = 5007;
                      end

                   elseif ((d0 >=200) &&  (d0 < 300))

                         if ((mxfp <= 192)&&(mxfp >= 64))
                                   
                                        if (c0 < 100)
                                            if(mfp <= 128)
                                             id3(idx) = 5002;   
                                            else
                                             id3(idx) = 5003;   
                                            end
                                        elseif ((c0 >= 100) && (c0 < 200))
                                          id3(idx) = 5004;                     
                                        else
                                          id3(idx) = 5005;             
                                        end  
            
                                  elseif (mxfp <= 64)
                                   id3(idx) = 5006;
                                  else
                                   id3(idx) = 5007;
                         end


                   elseif ((d0 >=300) &&  (d0 < 400))
            
                         if ((mxfp <= 192)&&(mxfp >= 64))
                                   
                                        if (c0 < 100)
                                            if(mfp <= 128)
                                             id3(idx) = 5002;   
                                            else
                                             id3(idx) = 5003;   
                                            end
                                        elseif ((c0 >= 100) && (c0 < 200))
                                          id3(idx) = 5004;                     
                                        else
                                          id3(idx) = 5005;             
                                        end  
            
                                  elseif (mxfp <= 64)
                                   id3(idx) = 5006;
                                  else
                                   id3(idx) = 5007;
                         end

                   elseif ((d0 >=400))

                      if ((mxfp <= 192)&&(mxfp >= 64))
                       
                            if (c0 < 100)
                                if(mfp <= 128)
                                 id3(idx) = 5002;
                                else
                                 id3(idx) = 5003;   
                                end
                            elseif ((c0 >= 100) && (c0 < 200))
                              id3(idx) = 5004;                     
                            else
                              id3(idx) = 5005;             
                            end  

                      elseif (mxfp <= 64)
                       id3(idx) = 5006;
                      else
                       id3(idx) = 5007;
                      end

                   end
    
    
               end
    
    
           end
      end

    end
    
end

%% ------------------------------------------------------------------------

for idx = 1:length(history)

flag = history(idx).flag;
a1 = history(idx).a1;
a2 = history(idx).a2;
L01 = length(a1)+ length(a2);        

gap = history(idx).gap;
    
coeffp1 = history(idx).coef;
cr_nor = history(idx).cr_nor;
[~,rp_max] = max(-1*cr_nor);
[~,rp_min] = min(-1*cr_nor);

cr_raw = history(idx).cr_raw;
rp_p = find(-1*(cr_nor) > 1e4);
rp_p_l = length(rp_p);
rp_var = var(cr_nor);


    if ((id3(idx) == 1) && (gap < 300))
        id3(idx) = 1000;
    end

    if ((id3(idx) == 1) && (coeffp1 < 0) && (gap > 300)) 

      if ((rp_max >= 128) && (rp_min <= 128) && (rp_p_l >= 16))
             id3(idx) = 2002;
     elseif ((rp_max <= 128) && (rp_min >= 128) && (rp_min <= 240) && (rp_p_l >= 1))
             id3(idx) = 2003;
      else
                        if (rp_var < 3e6)
                                   id3(idx) = 2004;
                        else
                                if ((rp_max >= 128) && (rp_min <= 128))
                                   id3(idx) = 2002;
                                elseif ((rp_max <= 128) && (rp_min >= 128) && (rp_min <= 240))
                                   id3(idx) = 2004;
                                else
                                    if ((rp_max >= 128) || (rp_min <= 128))
                                     id3(idx) =2003;
                                    elseif ((rp_max <= 128) || (rp_min >= 128))
                                     id3(idx) = 2003;
                                    else
%                                      id3(idx) = 2011; % empty
                                    end

                                end
                        end
      end

            
    end


flag = history(idx).flag;
a1 = history(idx).a1;
a2 = history(idx).a2;
L01 = length(a1)+ length(a2);       
gap = history(idx).gap;
    
coeffp1 = history(idx).coef;
f_part_length = history(idx).f_part_length;
f_part_num = history(idx).f_part_num;

cr_nor = history(idx).cr_nor;
[~,rp_max] = max(cr_nor);
[~,rp_min] = min(cr_nor);

cr_raw = history(idx).cr_raw;
rp_p = find((cr_raw) > 20);
rp_p_l = length(rp_p);

rp_p_min = min(rp_p);
rp_p_max = max(rp_p);

rp_num1 = history(idx).r_part_num;
rp_part = history(idx).r_part;

rp_p_max = max(max(rp_part));
rp_p_min = min(min(rp_part));

    if ((id3(idx) == 1) && (coeffp1 > 0) && (gap > 300)) 

       if ((rp_max > 192)||(rp_min < 64) )
         id3(idx) = 3001;
       elseif ((rp_max < 64)||(rp_min > 192))
         id3(idx) =  3002;
       end

    elseif ((id3(idx) == 1) && (coeffp1 > 0)) 
          id3(idx) =  3003;
    end

    if (id3(idx) == 1)
         id3(idx) =  3002;
    end
    
end

id3(find(id3 == 0)) = 1000;
id3 = floor((id3-1)/1e3);
save([path2,'\processing\re_sort0.mat'],'id3')

