clc;clear;close all

path2 = cd; 

load smoothing2.mat;
load file_name;

history2(length(file_name)).w_id = [];

for idx = 1:length(history)
   fname1 = history(idx).filename;

   for idx2 = 1:length(file_name)
     fname2 = file_name{idx2};
     if (length(fname2) == length(fname1))
         if sum(fname2 == fname1) == length(fname1) 
             dum = [];
             dum = history2(idx2).w_id;
             dum2 = [dum,idx];
             history2(idx2).w_id = dum2;
         end
     
     end
   
   end
   
  clc;
  fprintf('%f \n', idx);
end

save([path2,'\processing\file_base.mat'],'history2');