%% before pp2 -- > generating 'smoothing3.mat'
%% 'smoothing3.mat' contain values 'database1' and 'f_point2'

% clc;clear;

load filter2.mat

path2 = cd; 
database = contour_ex;
idx3 = 1;

idx55 = 1;
for idx00 = 1:length(database)
z5 = database(idx00).d;

for idx = 1:length(z5)
tt = z5(idx).time;
ff = z5(idx).freq;
QQ = z5(idx).Quality;
f_name = z5(idx).filename;
idx7 = 1;
tt2 = [];
ff2 = [];
direction1 = tt(end)-tt(1); 
for idx3  = 1: length (tt)-1

if length(tt2) > 0 % tt2 생성 이후
     if direction1 > 0 % 증가 방향
      
        if (tt(idx3+1) - tt2(idx7-1)) > 0  % 다음게 큼 올바름 
               tt2(idx7) = tt(idx3);
               ff2(idx7) = ff(idx3);
               idx7 = idx7+1;
                if (tt2(idx7-1) - tt2(idx7-2)) < 0 % 앞서 sortting한게 다 잘못됫음
                    if length(tt2)/length(tt) < 0.5                     
                    tt2 = [];
                    ff2 = [];
                    tt2(1) = tt(idx3);
                    ff2(1) = ff(idx3);
                     idx7 = 2;
                    else
                     if  tt2(idx7-2) - tt(idx3) > 0
                       tt2(idx7-1) = [];
                       ff2(idx7-1) = [];
                       idx7 = idx7-1;
                     end
                    end
                end
        end
    
     else % 감소 방향
       
         if (tt2(idx7-1) - tt(idx3+1)) > 0  % 다음게 작음 올바름 
           tt2(idx7) = tt(idx3);
           ff2(idx7) = ff(idx3);
           idx7 = idx7+1;
                if (tt2(idx7-1) - tt2(idx7-2)) > 0 % 앞서 sortting한게 다 잘못됫음
                    if length(tt2)/length(tt) < 0.5                     
                    tt2 = [];
                    ff2 = [];
                    tt2(1) = tt(idx3);
                    ff2(1) = ff(idx3);
                     idx7 = 2;
                    else
                     if  tt2(idx7-2) - tt(idx3) < 0
                       tt2(idx7-1) = [];
                       ff2(idx7-1) = [];
                       idx7 = idx7-1;
                     end
                    end
                end
         end
    
     end
else % tt2 생성 이전

     if direction1 > 0 % 증가 방향      
        if (tt(idx3+1) - tt(idx3)) > 0  % 다음게 큼 올바름 
           tt2(idx7) = tt(idx3);
           ff2(idx7) = ff(idx3);
           idx7 = idx7+1;
        end    
     else % 감소 방향       
         if (tt(idx3) - tt(idx3+1)) > 0  % 다음게 작음 올바름 
           tt2(idx7) = tt(idx3);
           ff2(idx7) = ff(idx3);
           idx7 = idx7+1;
         end    
     end

end
 
end

database3(idx55).filename = f_name;
database3(idx55).time = tt2;
database3(idx55).freq = ff2;
database3(idx55).quality = QQ;
idx55 = idx55 + 1;
end

end

idx3 = 1;
idx55 = 1;
idx552 = 1;
for idx = 1:length(database3)
dum = database3(idx);
    
        dum2_2 = dum.time;
        [dum2,id_ascend] = sort(dum2_2,"ascend");
        dum3_2 = dum.freq;
        dum3 = dum3_2(id_ascend);
        dum5 = dum.filename;
        dum2 = dum2 - min(dum2);
        dum_Q = dum.quality;
        if length(dum2) > 1
            [w1_point_t_re,w1_point_f_re] = re_point_tf2(dum2,dum3,0.001);
            [w1_point_t_re2,w1_point_f_re2] = re_point_tf2(dum2,dum3,max(dum2)/255);

    
            if (length(w1_point_t_re) > 4) || max(dum2) > 1e-3
    
            database1(idx3).time = w1_point_t_re;
            database1(idx3).freq = w1_point_f_re;
            database1(idx3).filename = dum5;
            database1(idx3).st = min(dum2_2);
            database1(idx3).quality = dum_Q;
            z = w1_point_f_re2;
            z2 = filtfilt(Num2,1,z);
            z3 = z2./mean(z2)*mean(z);
            f_point2(idx3,:) = z3;
    
            idx3 = idx3 + 1;
   
            else

            dumdum2(idx552) = dum;   
            idx552 = idx552 + 1;

            end
        else
         dumdum(idx55) = dum;

            idx55 = idx55 + 1;
        end 
         clc;
        fprintf('id: %f id3: %f\n',idx ,idx3);

end



idx_abs = 0;
idx_dob = 0;
% L0 = 0;

for idx = 1:length(database1)
  dum2 = database1(idx).quality;
%   L0 = L0 + length(dum);
%    for idx2 = 1:length(dum)
%       dum2 = dum(idx2).Quality;
      if dum2(1) == 'A'
          idx_abs = idx_abs + 1;
      elseif dum2(1) == 'D'
          idx_dob = idx_dob + 1;
      end

%    end

end

save([path2,'\processing\smoothing3.mat'],'database1','f_point2');

for idx = 1:length(database)

z_3 = database(idx).d;
z3 = z_3(1).filename;
file_name{idx} = z3;
end

save([path2,'\processing\file_name.mat'],'file_name');