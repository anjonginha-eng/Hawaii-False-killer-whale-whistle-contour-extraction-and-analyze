clc;
clear;
close all;

path2 = cd;     

load('file_base.mat', 'history2')
load('smoothing2.mat')
load file_name
load file_base
load re_sort0.mat


p_origin = unique(id3);
record(length(p_origin)).charact = [];


count1(1e4,length(p_origin)) = 0;

case_id1 = [1,108];

for idx = 1:length(history2)
w_id = history2(idx).w_id;

    for idx2 = 1:length(w_id) 
          p_id = id3(w_id(idx2)); %%%%
          p_id2 = find(p_origin == p_id);

          ff = history(w_id(idx2)).point;
          tt = history(w_id(idx2)).tt;
          intvl = history(w_id(idx2)).intvl;
          [~,mp]=min(ff);
          mfp = intvl(mp);
          mxfp = intvl(mp);
                      
         [mmmp ,mpp]=max(ff);
          mpm = min(find(intvl > 192));
          mpm2 = ff(mpm);
          gap3 = abs(mpm2 - mmmp);
          
          a1 = history(w_id(idx2)).a1;
          a2 = history(w_id(idx2)).a2;
          L01 = length(a1)+ length(a2);         % L01: 변곡점 갯수

          cr_nor = history(w_id(idx2)).cr_nor;
          rp_var = var(cr_nor);
          [~,rp_max] = max(-1*cr_nor); 
          [~,rp_min] = min(-1*cr_nor);

          d1 = history(w_id(idx2)).d1;
          d2 = history(w_id(idx2)).d2;
          
          if (isempty(d1) == 1)&&(isempty(d2) == 0)
                up_down = 0;
          elseif(isempty(d1) == 0)&&(isempty(d2) == 1)
                up_down = 1;
          else
                up_down = -1;
          end


          if isempty(max(d2))
           ddd2 = -1;
          else
           ddd2 = max(d2);
          end
          if isempty(max(d1))
           ddd1 = -1;
          else
           ddd1 = max(d1);
          end


          if isempty(d1)
                 d1 = 0;
          end
          if isempty(d2)
                 d2 = 0;
          end
          d0 = max([d1,d2]);
          d0_2 = ([d1,d2]);
          if isempty(d0)
          d0 = 0;
          end
          gap = history(w_id(idx2)).gap;
          c_devi = d0/gap;
          d0_1 = d0_2(find(d0_2> 150));
          dtmean2=mean([d1,d2]);

          d0min = min([d1,d2]);
          if isempty(d0min)
          d0min = 0;
          end
        
          c1 = history(w_id(idx2)).c1;
          c2 = history(w_id(idx2)).c2;
          if isempty(c1)
              c1 = 0;
          end
        
          if isempty(c2)
             c2 = 0;
          end
          c0 = max([c1,c2]);
          f_part_length = history(w_id(idx2)).f_part_length;

            
            if  ddd1 > ddd2
                peak2 = 1; % ^ shape
            else
                peak2 = 0; % u shape
            end
  
          charact(1) = max(tt);                   % 1: time length
          charact(2) = max(ff);                   % 2: max frequency
          charact(3) = min(ff);                   % 3: min frequency
          charact(4) = history(w_id(idx2)).gap;       % 4: 주파수 범위
          charact(5) = L01;                       % 5: 변곡점 갯수
          charact(6) =history(w_id(idx2)).coef;       % 6: line fitting coefficient
          charact(7) =history(w_id(idx2)).f_part_num; % 7: flat part num
          charact(8) =history(w_id(idx2)).r_part_num; % 8: rapid part num
          charact(9) =rp_max;                     % 9: rp_max loc
          charact(10) =rp_min;                    % 10: rp_min loc
          charact(11) =d0;                        % 11: max prominence
          charact(12) =d0min;                     % 12: min prominence
          charact(13) =mfp;                       % 13: maximum freqeuncy loc
          charact(14) =c0;                        % 14: maximum of peak bandwidth
          charact(15) =length(d0_1);              % 15: number of prominence over 150
          charact(16) =f_part_length;             % 16: flat part length 
          charact(17) =c_devi;                    % 17: chirp rate devi 
          charact(18) = dtmean2;                  % 18: prominence mean
          charact(19) = rp_var;                   % 19: chir rate variance
          charact(20) = gap3;                     % 20: end part min frequency
          charact(21) = up_down;                  % 21: up down characteristic
          charact(22) = mpp;                      % 22: max frequency loc
          charact(23) = mp;                       % 23: min frequency loc ratio
          charact(24) = mxfp;                     % 24: max frequency time loc
          charact(25) = peak2;                    % 25: shape character index
          charact(26) = ff(1);                    % 26: start frequency
          charact(27) = ff(end);                    % 27: end frequency
          charact(28) = w_id(idx2);                  

     dum = record(p_id2).charact;
     record(p_id2).charact = [dum;charact];
    end

end


dum_length = length(record_p(1).charact);
if dum_length == 1615
    record_p1 = record;
    save([path2,'\analysis result\record_p1.mat'],'record_p1');

elseif dum_length == 8346
    record_p2 = record;
    save([path2,'\analysis result\record_p2.mat'],'record_p2');

elseif dum_length == 349
    record_p3 = record;
    save([path2,'\analysis result\record_p3.mat'],'record_p3');

end


