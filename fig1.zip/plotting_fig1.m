clc;clear;

baseDir = cd;  %
f1 = fullfile(baseDir,'Falsekiller_MHI_line.shp');
f2 = fullfile(baseDir,'Falsekiller_NWHI_Line.shp');
f3 = fullfile(baseDir,'pFKW_MgmtArea_line.shp');

assert(exist(f1,'file')==2 && exist(f2,'file')==2 && exist(f3,'file')==2, 'check shp-file dierctory');

F = {f1,f2,f3};
S = cell(1,3);
for i = 1:3
    S{i} = shaperead(F{i});  
    if isfield(S{i},'Lat') && ~isfield(S{i},'X')
        S{i} = shaperead(F{i});
    end
end

haveProj = (exist('projcrs','file')==2) && (exist('projinv','file')==2);
if haveProj
    crs = projcrs(32604); 
else
    mstruct = defaultm('utm');           
    mstruct.zone = '4N';                 
    ell = wgs84Ellipsoid('meters');
    mstruct.geoid = [ell.SemimajorAxis ell.Eccentricity]; % [a, e]
    mstruct = defaultm(mstruct);
end

for i = 1:3
    for k = 1:numel(S{i})
        x = S{i}(k).X; y = S{i}(k).Y;      
        lat = nan(size(x)); lon = nan(size(y));
        mask = isfinite(x) & isfinite(y);   
        if haveProj
            [lat(mask), lon(mask)] = projinv(crs, x(mask), y(mask));
        else
            [lat(mask), lon(mask)] = minvtran(mstruct, x(mask), y(mask));
        end
        S{i}(k).Lat = lat; S{i}(k).Lon = lon;  
    end
end

latAll = []; lonAll = [];
for i = 1:3
    latAll = [latAll, S{i}.Lat]; 
    lonAll = [lonAll, S{i}.Lon]; 
end
latAll = latAll(isfinite(latAll)); lonAll = lonAll(isfinite(lonAll));
assert(~isempty(latAll),'fail to transmit.');

latPad = max(0.2, 0.05*(max(latAll)-min(latAll)));
lonPad = max(0.2, 0.05*(max(lonAll)-min(lonAll)));
latlim = [max(-89.9, min(latAll)-latPad), min(89.9, max(latAll)+latPad)];
lonlim = [max(-180,  min(lonAll)-lonPad), min(180,  max(lonAll)+lonPad)];

    figure('Color','w');
    gx = geoaxes; hold(gx,'on');
    geobasemap(gx,'streets');   
    names = {'MHI','NWHI','Pelagic'};
    cols  = [0 1 0; 1 0 0; 0 0 1];
    H = gobjects(3,1);

    for i = 1:2
        first = true;
        for k = 1:numel(S{i})
            lt = S{i}(k).Lat; ln = S{i}(k).Lon;
            if ~any(isfinite(lt)), continue; end
            if first
                H(i) = geoplot(gx, lt, ln, '-', 'LineWidth',2, 'Color', cols(i,:), 'DisplayName', names{i});
                first = false;
            else
                geoplot(gx, lt, ln, '-', 'LineWidth',2, 'Color', cols(i,:));
            end
        end
    end

    for i = 3
        first = true;
        for k = 1:numel(S{i})
            lt = S{i}(k).Lat; ln = S{i}(k).Lon;
            ln(174:234) = ln(174:234)*-1;
            if ~any(isfinite(lt)), continue; end
            if first
                H(i) = geoplot(gx, lt, ln, '-', 'LineWidth',2, 'Color', cols(i,:), 'DisplayName', names{i});
                first = false;
            else
                geoplot(gx, lt, ln, '-', 'LineWidth',2, 'Color', cols(i,:));
            end
        end
    end
    geolimits(gx, latlim, lonlim);
    legend(gx, H(H~=0), names(H~=0), 'Location','best');

   % NWHI 
    geoplot(gx, 25.1844783333333, -172.855825, 'r*', 'LineWidth',2, 'DisplayName',['NWHI-1']);
    geoplot(gx,21.925415, -162.226975, 'r^', 'LineWidth',2, 'DisplayName',['NWHI-2']);

   
  % pelagic
    geoplot(gx, 23.53336167, -175.75688, 'bo', 'LineWidth',2, 'DisplayName', ['Pelagic-1']);
    geoplot(gx,23.841, -173.74306, 'b^', 'LineWidth',2, 'DisplayName',['Pelagic-2']);
    geoplot(gx,22.903645, -154.188128333333, 'b*', 'LineWidth',2, 'DisplayName',['Pelagic-3']);


    % MHI
    geoplot(gx, 21.17765, -156.103516666667, 'g*', 'LineWidth',2, 'DisplayName', ['MHI-1']);
    geoplot(gx, 21.03351667, -157.2159033, 'go', 'LineWidth',2, 'DisplayName',['MHI-2']);
    geoplot(gx,20.8759116666667, -158.637126666667, 'g^', 'LineWidth',2, 'DisplayName',['MHI-3']);


  % 
  % xlabel('Longitude');
  % ylabel('Latitude');