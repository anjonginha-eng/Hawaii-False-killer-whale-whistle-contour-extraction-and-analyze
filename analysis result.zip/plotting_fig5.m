
% 1. falt
% 2. Sin
% 3. Down sweep
% 4. Up sweep
% 5. invert U sahpe
% 6. U shape


clc;clear;
load record_p1.mat;
load record_p2.mat;
load record_p3.mat;

for idx = 1:6
NWHI(idx) = size((record_p1(idx).charact),1);
pelagic(idx) = size((record_p2(idx).charact),1);
MHI(idx) = size((record_p3(idx).charact),1);
end

figure(1);
hold on;stem(NWHI./sum(NWHI),'r','LineWidth',2,'MarkerSize',7)
hold on;stem(pelagic./sum(pelagic),':b','LineWidth',2,'MarkerSize',5)
hold on;stem(MHI./sum(MHI),':g','LineWidth',2,'MarkerSize',3)

box on;
set(gca, 'FontSize', 12);
legend(['NWHI'],['Pelagic'],['MHI']);

ylabel('Probability');
xlabel('Time-Frequency Contour Shape');
xticks([1:6]);
xticklabels({'flat','Sin','up','down','Invert U','U'});