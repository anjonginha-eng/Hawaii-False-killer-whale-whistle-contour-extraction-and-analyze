clc;
clear;

rng(42);                 % 재현성 고정
B    = 1000;             % 반복 수
nPer = 100;              % 집단별 부트스트랩 샘플 크기
load record_p1.mat % NWHI
load record_p2.mat % pelagic
load record_p3.mat % MHI

idx_c0 = [1 2 3 4 26 27];
for idx_p = 6
for idx_c = 1:6 
% --- 입력 정리 ---
p1_dum = record_p1(idx_p).charact; 
p2_dum = record_p2(idx_p).charact; 
p3_dum = record_p3(idx_p).charact;
idx_c2 = idx_c0(idx_c);

p1  = p1_dum(:,idx_c2); 
p2  = p2_dum(:,idx_c2); 
p3  = p3_dum(:,idx_c2);

% y   = [p1; p2; p3];

   alpha = 0.05;
   %  [h,p] = adtest(y);  % Anderson–Darling (정규성)
   %  [h1,p_1] = adtest(p1);  
   %  [h2,p_2] = adtest(p2);  
   %  [h3,p_3] = adtest(p3); 
   % 
   % grp = [ones(numel(p1),1); 2*ones(numel(p2),1); 3*ones(numel(p3),1)];
   % [p,stats] = vartestn(y, grp, 'TestType','BrownForsythe', 'Display','off'); % equal variance test -> result no


   dataSets = {
       {p1, p2, p3}};

B = 1000;          % bootstrap 반복 수(권장: 1000~5000)
alpha = 0.05;      % 유의수준
mc_method = 'holm';% 다중비교 보정: 'holm' 또는 'bh'
rng(42);           % 재현성

results = analyze_welch_gameshowell3(dataSets, B, alpha, mc_method);

fprintf('\n -----------------------------------------');
fprintf('\n contour shape id:%d , character id: %d \n',idx_p,idx_c);
% 전역 Welch ANOVA
disp(results(1).welch)

% 쌍별(평균차, Welch t, 보정 p, Cohen's d 점추정)
disp(results(1).gameshowell.table)

% 부트스트랩 CI (평균차 & Cohen's d)
disp(results(1).bootstrap.mean)   % Δ mean의 부트스트랩 CI
disp(results(1).bootstrap.d)      % Cohen's d의 부트스트랩 CI

% TOST (등가성)
disp(results(1).tost.table)

fprintf('\n -----------------------------------------');
end

end