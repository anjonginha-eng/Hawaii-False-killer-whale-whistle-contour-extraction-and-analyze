
% 1. falt
% 2. Sin
% 3. Down sweep
% 4. Up sweep
% 5. invert U sahpe
% 6. U shape


clc;clear;
load record_p1.mat;
load record_p2.mat;
load record_p3.mat;

for idx = 1:6
 record(idx).charact = [record_p1(idx).charact;record_p2(idx).charact;record_p3(idx).charact];
end

close all;
for c_idx = 1:2 
    c_id2 = [6 24]
for  p_idx = 1:6

        
         
        dum = record(p_idx);
        dum0 = dum.charact;
        dum2 = dum0(:,c_id2(c_idx));

        x_values =  min(min(dum2)):(max(max(dum2))-min(min(dum2)))/20:max(max(dum2));

        if ((isempty(x_values) == 0) && (sum(isnan(x_values)) == 0))            
                    pd = fitdist(dum2,'Kernel','Kernel','epanechnikov');
                    modeling_result(p_idx,c_idx).m = pd;
                    
                    y = pdf(pd,x_values);
                    y(find(y == 0)) = 1e-10;
                    y_total(p_idx,:) = y./sum(y); 
            
         end

        clear y
    
end


figure(c_idx);plot(x_values,y_total(1,:),'r')
hold on;plot(x_values,y_total(2,:),'g')
hold on;plot(x_values,y_total(3,:),'b')
hold on;plot(x_values,y_total(4,:),'k')
hold on;plot(x_values,y_total(5,:),'m')
hold on;plot(x_values,y_total(6,:),'c')

legend(['flat'],['Sin'],['up'],['down'],['invert'],[' U']);

if c_idx == 1
  axis([-60 40 0 0.8])
  xlabel('Whistle line fitting coefficient');
  ylabel('Probability');set(gca, 'FontSize', 12); 
  grid on; box on;
else
  axis([0 250 0 0.22])
  xlabel('Whistle time part segment(1-256)');
  ylabel('Probability');set(gca, 'FontSize', 12); 
  grid on; box on;
end

end
