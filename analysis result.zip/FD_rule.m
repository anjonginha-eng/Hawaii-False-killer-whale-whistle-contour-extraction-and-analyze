function [outputArg1] = FD_rule(data)
% Freedman-Diaconis Rule
%   자세한 설명 위치

Q1 = quantile(data,0.25);
Q3 = quantile(data,0.75);
IQR = Q3 - Q1;
n = length(data);
binwidth = 2*IQR*n^(-1/3);
binEdges = min(data):binwidth:max(data);

outputArg1 = binEdges;
end