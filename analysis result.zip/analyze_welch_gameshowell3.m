function results = analyze_welch_gameshowell3(dataSets, B, alpha, mc_method, opts)
% ANALYZE_WELCH_GAMESHOWELL
% Welch ANOVA → 쌍별 Welch t(+Holm/BH) + Cohen's d → 계층부트스트랩 CI
% → TOST(등가성): ★세트별 SESOI(±Δ_set)를 데이터를 통해 '자동 추정' 후 그 Δ_set로만 판단★
%
% Inputs
%   dataSets : 1xS cell, 각 원소는 1xK cell {g1,g2,...,gK} (NaN 제거)
%   B        : bootstrap 반복 수 (기본 2000)
%   alpha    : 유의수준 (기본 0.05; TOST는 90% CI 사용)
%   mc_method: 'holm'(기본) 또는 'bh'
%   opts     : (옵션) 구조체
%              .sesoi.d0 (기본 0.2)      % Cohen의 'small' 효과크기
%              .sesoi.strategy ('auto')   % 'auto'|'pooledSD'|'robustMAD'
%              .sesoi.hetero_thr (4)      % 이분산 지표 = max(s^2)/min(s^2) 임계
%              .sesoi.kurt_thr (6)        % 꼬리(첨도) 임계 (excess 기준 대략)
%
% Outputs (per set s)
%   results(s).welch        : Welch ANOVA 결과
%   results(s).gameshowell  : 쌍별 Welch t + p_adj + Cohen's d(점추정)
%   results(s).bootstrap    : Δ mean 및 d의 부트스트랩 CI
%   results(s).sesoi        : 자동 추정된 Δ_set과 추정 메타데이터
%   results(s).tost         : TOST 결과(Δ_set, delta_min, feasible, 90% CI, p_equiv_adj, equivalent)

    if nargin < 4 || isempty(mc_method), mc_method = 'holm'; end
    if nargin < 3 || isempty(alpha), alpha = 0.05; end
    if nargin < 2 || isempty(B), B = 2000; end
    if nargin < 5, opts = struct(); end
    if ~isfield(opts,'sesoi'), opts.sesoi = struct(); end
    if ~isfield(opts.sesoi,'d0'),         opts.sesoi.d0 = 0.2; end
    if ~isfield(opts.sesoi,'strategy'),   opts.sesoi.strategy = 'auto'; end
    if ~isfield(opts.sesoi,'hetero_thr'), opts.sesoi.hetero_thr = 4; end
    if ~isfield(opts.sesoi,'kurt_thr'),   opts.sesoi.kurt_thr = 6; end

    S = numel(dataSets);
    results = repmat(struct('welch',[], 'gameshowell',[], 'bootstrap',[], 'sesoi',[], 'tost',[]), S, 1);

    for s = 1:S
        groups = dataSets{s};
        assert(iscell(groups) && ~isempty(groups), '각 set은 {g1,g2,...,gK} 셀이어야 합니다.');

        % 1) Welch ANOVA
        welch = welch_anova(groups);

        % 2) Pairwise Welch t (+ adjusted p) + Cohen's d (point)
        gh = games_howell_with_d(groups, alpha, mc_method);

        % 3) Stratified bootstrap CI for Δ mean & Cohen's d
        boot = bootstrap_pairwise_mean_and_d(groups, B, alpha);

        % 4) SESOI(±Δ_set) 자동 추정
        sesoi = infer_sesoi_from_data(groups, opts.sesoi);

        % 5) TOST with FIXED (auto-inferred) SESOI
        tost = tost_pairwise_welch_FIXED(groups, sesoi.delta_set, alpha, mc_method);

        results(s).welch       = welch;
        results(s).gameshowell = gh;
        results(s).bootstrap   = boot;
        results(s).sesoi       = sesoi;   % delta_set, method, d0, s_est 등
        results(s).tost        = tost;
    end
end

% -------------------- (A) SESOI 추정 --------------------
function out = infer_sesoi_from_data(groups, cfg)
% 결과 Δ_set = d0 * s_est
% s_est 추정 방식:
%   strategy = 'pooledSD'  : within-group pooled SD
%            = 'robustMAD' : median(MAD_i*1.4826)
%            = 'auto'      : 이분산/꼬리 심하면 'robustMAD', 아니면 'pooledSD'
    K = numel(groups);
    n = zeros(K,1); s2 = zeros(K,1); sMAD = zeros(K,1); kur = zeros(K,1);
    allx = [];
    for i = 1:K
        xi = groups{i}; xi = xi(~isnan(xi));
        n(i) = numel(xi);
        s2(i) = var(xi,0);
        sMAD(i) = mad(xi,0);    % scaled MAD = MAD*1.4826 (정규 등가 SD)
        kur(i) = kurtosis(xi);  % MATLAB: 표본 첨도(정규분포=3). 아래서는 대략적 지표로 사용
        allx = [allx; xi(:)]; %#ok<AGROW>
    end
    hetero_ratio = max(s2)/max(min(s2), eps);
    max_kurt     = max(kur);

    % 기본 방법 선택
    method = cfg.strategy;
    if strcmpi(method,'auto')
        if hetero_ratio > cfg.hetero_thr || (max_kurt-3) > cfg.kurt_thr   % (excess) 대략 판정
            method = 'robustMAD';
        else
            method = 'pooledSD';
        end
    end

    switch lower(method)
        case 'pooledsd'
            s_est = sqrt( sum((n-1).*s2) / sum(n-1) );
        case 'robustmad'
            s_est = median(sMAD);
        otherwise
            error('opts.sesoi.strategy는 ''auto''|''pooledSD''|''robustMAD'' 중 하나여야 합니다.');
    end
    % 비정상 상황 보정
    if ~isfinite(s_est) || s_est<=0
        s_est = std(allx,0);    % 최후 보정
    end

    delta_set = cfg.d0 * s_est;

    out = struct();
    out.delta_set    = delta_set;     % 이 Δ로만 TOST 판단
    out.method       = method;        % 채택된 방법
    out.d0           = cfg.d0;        % 사용한 d0 (기본 0.2)
    out.s_est        = s_est;         % 선택된 within SD 추정치
    out.hetero_ratio = hetero_ratio;  % 이분산 지표
    out.max_kurt     = max_kurt;      % 꼬리/첨도 지표(참고)
end

% -------------------- (B) Welch one-way ANOVA --------------------
function out = welch_anova(groups)
    K = numel(groups);
    n = zeros(K,1); m = zeros(K,1); s2 = zeros(K,1);
    for i = 1:K
        xi = groups{i}; xi = xi(~isnan(xi));
        n(i)  = numel(xi);  if n(i) < 2, error('집단 %d의 표본수가 2 미만입니다.', i); end
        m(i)  = mean(xi);
        s2(i) = var(xi, 0);  groups{i} = xi; %#ok<AGROW>
    end
    w  = n ./ s2;  W = sum(w);  mw = sum(w .* m) / W;  df1 = K - 1;
    num  = sum( w .* (m - mw).^2 ) / df1;
    term = sum( ((1 - w/W).^2) ./ (n - 1) );
    c    = 1 + (2*(K - 2) / (K^2 - 1)) * term;
    Fw   = num / c;
    df2  = (K^2 - 1) / (3 * term);
    p    = 1 - fcdf(Fw, df1, df2);
    out = struct('F', Fw, 'df1', df1, 'df2', df2, 'p', p, ...
                 'k', K, 'n', n, 'means', m, 'vars', s2, 'weights', w, 'mw', mw);
end

% -------------------- (C) Pairwise Welch t (+ adjusted p) + Cohen's d --------------------
function out = games_howell_with_d(groups, alpha, mc_method)
    K = numel(groups);
    n = zeros(K,1); m = zeros(K,1); s2 = zeros(K,1);
    for i = 1:K
        xi = groups{i}; xi = xi(~isnan(xi));
        n(i)  = numel(xi);  if n(i) < 2, error('집단 %d의 표본수가 2 미만입니다.', i); end
        m(i)  = mean(xi);
        s2(i) = var(xi, 0); groups{i} = xi; %#ok<AGROW>
    end
    pairs = nchoosek(1:K, 2);  P = size(pairs,1);
    diff = zeros(P,1); SE = zeros(P,1); df = zeros(P,1);
    tval = zeros(P,1); pRaw = zeros(P,1); d_cohen = zeros(P,1);

    for p = 1:P
        i = pairs(p,1); j = pairs(p,2);
        diff(p) = m(i) - m(j);
        SE(p)   = sqrt( s2(i)/n(i) + s2(j)/n(j) );
        df(p)   = (s2(i)/n(i) + s2(j)/n(j))^2 / ( (s2(i)/n(i))^2/(n(i)-1) + (s2(j)/n(j))^2/(n(j)-1) );
        tval(p) = abs(diff(p)) / SE(p);
        pRaw(p) = 2*(1 - tcdf(tval(p), df(p))); % 양측

        % Cohen's d (pooled SD)
        sp2 = ((n(i)-1)*s2(i) + (n(j)-1)*s2(j)) / (n(i)+n(j)-2);
        sp  = sqrt(sp2);
        if sp==0, d_cohen(p) = NaN; else, d_cohen(p) = diff(p) / sp; end
    end
    switch lower(mc_method)
        case 'holm', pAdj = holm_adjust(pRaw);
        case 'bh',   pAdj = bh_adjust(pRaw);
        otherwise,   error('mc_method는 ''holm'' 또는 ''bh'' 중 하나여야 합니다.');
    end
    tcrit = tinv(1 - alpha/2, df);
    CI_lo = diff - tcrit .* SE;  CI_hi = diff + tcrit .* SE;

    T = table(pairs(:,1), pairs(:,2), diff, SE, df, tval, pRaw, pAdj, CI_lo, CI_hi, d_cohen, ...
      'VariableNames', {'grp_i','grp_j','meanDiff','SE','df','t','p_raw','p_adj','CI_t_lo','CI_t_hi','cohens_d'});
    out.table = T;
end

% -------------------- (D) Stratified bootstrap: CI for Δ mean & Cohen's d --------------------
function out = bootstrap_pairwise_mean_and_d(groups, B, alpha)
    K = numel(groups);  n = zeros(K,1);
    for i = 1:K
        xi = groups{i}; xi = xi(~isnan(xi));
        n(i) = numel(xi);  if n(i) < 2, error('집단 %d의 표본수가 2 미만입니다.', i); end
        groups{i} = xi; %#ok<AGROW>
    end
    pairs = nchoosek(1:K, 2);  P = size(pairs,1);

    % 원 데이터 점추정
    m = cellfun(@mean, groups(:));
    v = cellfun(@(x) var(x,0), groups(:));
    origDiff = zeros(P,1);  origD = zeros(P,1);
    for p = 1:P
        i = pairs(p,1); j = pairs(p,2);
        origDiff(p) = m(i) - m(j);
        sp2 = ((n(i)-1)*v(i) + (n(j)-1)*v(j)) / (n(i)+n(j)-2);
        sp  = sqrt(sp2);
        if sp==0, origD(p) = NaN; else, origD(p) = origDiff(p)/sp; end
    end

    bootDiff = zeros(B,P);  bootD = zeros(B,P);
    for b = 1:B
        means_b = zeros(K,1);  s2_b = zeros(K,1);
        for i = 1:K
            xi = groups{i};  ni = n(i);
            idx = randi(ni, ni, 1);   xb = xi(idx);
            means_b(i) = mean(xb);
            s2_b(i)    = var(xb,0);
        end
        for p = 1:P
            i = pairs(p,1); j = pairs(p,2);
            bootDiff(b,p) = means_b(i) - means_b(j);
            sp2b = ((n(i)-1)*s2_b(i) + (n(j)-1)*s2_b(j)) / (n(i)+n(j)-2);
            spb  = sqrt(sp2b);
            if spb==0, bootD(b,p) = NaN; else, bootD(b,p) = bootDiff(b,p)/spb; end
        end
    end

    lo = alpha/2; hi = 1 - alpha/2;
    CImean_lo = quantile(bootDiff, lo, 1)';   CImean_hi = quantile(bootDiff, hi, 1)';
    CId_lo    = quantile(bootD,    lo, 1)';   CId_hi    = quantile(bootD,    hi, 1)';

    Tmean = table(pairs(:,1), pairs(:,2), origDiff, CImean_lo, CImean_hi, ...
        'VariableNames', {'grp_i','grp_j','meanDiff','CI_boot_lo','CI_boot_hi'});
    Td = table(pairs(:,1), pairs(:,2), origD, CId_lo, CId_hi, ...
        'VariableNames', {'grp_i','grp_j','cohens_d','CI_boot_lo','CI_boot_hi'});
    out.mean = Tmean;  out.d = Td;  out.quantiles = [lo, hi];
end

% -------------------- (E) Pairwise TOST (고정 Δ_set = auto-inferred) --------------------
function out = tost_pairwise_welch_FIXED(groups, delta_set, alpha, mc_method)
    K = numel(groups);
    n = zeros(K,1); m = zeros(K,1); s2 = zeros(K,1);
    for i = 1:K
        xi = groups{i}; xi = xi(~isnan(xi));
        n(i)  = numel(xi);  if n(i) < 2, error('집단 %d의 표본수가 2 미만입니다.', i); end
        m(i)  = mean(xi);   s2(i) = var(xi, 0);  groups{i} = xi; %#ok<AGROW>
    end
    pairs = nchoosek(1:K, 2);  P = size(pairs,1);

    diff = zeros(P,1); SE = zeros(P,1); df = zeros(P,1);
    CI90_lo = zeros(P,1); CI90_hi = zeros(P,1); delta_min = zeros(P,1);
    p_lo = zeros(P,1); p_hi = zeros(P,1); p_eq = zeros(P,1); eq_bool = false(P,1);
    feasible = false(P,1);
    delta_input = repmat(delta_set, P, 1);

    for p = 1:P
        i = pairs(p,1); j = pairs(p,2);
        diff(p) = m(i) - m(j);
        SE(p)   = sqrt( s2(i)/n(i) + s2(j)/n(j) );
        df(p)   = (s2(i)/n(i) + s2(j)/n(j))^2 / ( (s2(i)/n(i))^2/(n(i)-1) + (s2(j)/n(j))^2/(n(j)-1) );

        if SE(p)==0
            CI90_lo(p) = diff(p); CI90_hi(p) = diff(p); delta_min(p) = abs(diff(p));
        else
            tcrit90 = tinv(1 - alpha, df(p));
            CI90_lo(p) = diff(p) - tcrit90*SE(p);
            CI90_hi(p) = diff(p) + tcrit90*SE(p);
            delta_min(p) = max(abs(CI90_lo(p)), abs(CI90_hi(p)));
        end

        % 고정 Δ_set로만 판단 (자동확대 없음)
        feasible(p) = (delta_set >= delta_min(p));
        t_lo = (diff(p) - (-delta_set)) / SE(p);   p_lo(p) = 1 - tcdf(t_lo, df(p));
        t_hi = (diff(p) - ( +delta_set)) / SE(p);  p_hi(p) = tcdf(t_hi, df(p));
        p_eq(p) = max(p_lo(p), p_hi(p));
        eq_bool(p) = (p_lo(p) < alpha) && (p_hi(p) < alpha);
    end

    % 다중보정: p_eq만
    switch lower(mc_method)
        case 'holm', p_eq_adj = holm_adjust(p_eq);
        case 'bh',   p_eq_adj = bh_adjust(p_eq);
        otherwise,   error('mc_method는 ''holm'' 또는 ''bh'' 중 하나여야 합니다.');
    end

    T = table(pairs(:,1), pairs(:,2), delta_input, delta_min, feasible, ...
              diff, SE, df, CI90_lo, CI90_hi, p_lo, p_hi, p_eq, p_eq_adj, eq_bool, ...
        'VariableNames', {'grp_i','grp_j','delta_set','delta_min','feasible', ...
                          'meanDiff','SE','df','CI90_lo','CI90_hi','p_lo','p_hi','p_equiv','p_equiv_adj','equivalent'});
    out.delta_set = delta_set;
    out.table = T;
end

% -------------------- (F) p-value adjustments --------------------
function p_adj = holm_adjust(p)
    [p_sorted, idx] = sort(p(:));  m = numel(p_sorted);
    adj = zeros(m,1);
    for i = 1:m, adj(i) = (m - i + 1) * p_sorted(i); end
    for i = 2:m, adj(i) = max(adj(i), adj(i-1)); end
    adj = min(adj, 1);
    p_adj = zeros(m,1);  p_adj(idx) = adj;
end

function p_adj = bh_adjust(p)
    [p_sorted, idx] = sort(p(:));  m = numel(p_sorted);
    q = (m ./ ( (1:m)' )) .* p_sorted;
    for i = m-1:-1:1, q(i) = min(q(i), q(i+1)); end
    q = min(q, 1);
    p_adj = zeros(m,1);  p_adj(idx) = q;
end
