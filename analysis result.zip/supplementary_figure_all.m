clc;
clear;
close all;


load('record_p1.mat');
load('record_p2.mat');
load('record_p3.mat');

t_range1 = [0:0.15:1.5];
t_range2 = [0:0.15:1.5];

f_range0 = [0:50:1e3];
f_range1 = [0:1e3:5e3];


f_range2 = [2e3:2.5e3:1.8e4];
f_range2_1 = [2e3:2.5e3:1.8e4];  % K, low, MHI 
y_limm = 0.25;
y_limm2 = 0.25;
x_limm2 = 15e3;

dense_c = 0.05;
FT_size = 10;
FT_size2 = 18;

for id_p = 1:6

dum_p1 = record_p1(id_p);
record2_p1 =  dum_p1.charact; %% NWHI r 

dum_p2 = record_p2(id_p);
record2_p2 = dum_p2.charact; %% Pelagic  b 

dum_p3 = record_p3(id_p);
record2_p3 = dum_p3.charact; %% MHI  g

fig1=figure(id_p*10+1);
x0=100;
y0=500;
width=500;
height=250;
set(fig1,'position',[x0,y0,width,height]);

range1=FD_rule(record2_p1(:,1)); % 1: time length
range2=FD_rule(record2_p2(:,1));
range3=FD_rule(record2_p3(:,1));
bin_width1 = range1(2) - range1(1);
bin_width2 = range2(2) - range2(1);
bin_width3 = range3(2) - range3(1);

[x1,y1] = hist(record2_p1(:,1),range1);
[x2,y2] = hist(record2_p2(:,1),range2);
[x3,y3] = hist(record2_p3(:,1),range3);

m = mean(record2_p1(:,1));
std1 = std(record2_p1(:,1));
hold on;fill([m-std1 , m-std1 ,m+std1,m+std1],[0,1,1,0],'r','FaceAlpha',dense_c,'Edgecolor','none')
hold on;stem(m,1,'r')
hold on;plot(y1,cumsum(x1)/(sum(x1)),'r');

m = mean(record2_p2(:,1));
std1 = std(record2_p2(:,1));
hold on;fill([m-std1 ,m-std1 , m+std1 , m+std1],[0,1,1,0],'b','FaceAlpha',dense_c,'Edgecolor','none')
hold on;stem(m,1,'b')
hold on;plot(y2,cumsum(x2)/(sum(x2)),'b');

m = mean(record2_p3(:,1));
std1 = std(record2_p3(:,1));
hold on;fill([m-std1 ,m-std1 , m+std1 , m+std1],[0,1,1,0],'g','FaceAlpha',dense_c,'Edgecolor','none')
hold on;stem(m,1,'g')
hold on;plot(y3,cumsum(x3)/(sum(x3)),'g');


xlabel('Time (sec)');
ylabel('Probability');
yRange = ylim;
axis([0 0.85 yRange]);
legend({'P1(NWHI): Std range','P1(NWHI): Avrg.','P1(NWHI): CDF',...
        'P2(Pelagic): Avrg.','P2(Pelagic): Std range','P2(Pelagic): CDF',...
        'P3(MHI): Avrg.','P3(MHI): Std range','P3(MHI): CDF',...
        },'Location','northeastoutside');
box on;
title('  ','FontSize',FT_size2);

saveas(fig1,[num2str(id_p),'1_bb.jpg']);
%%

% nexttile(2,[1,1]);
fig2=figure(id_p*10+2);
set(fig2,'position',[x0,y0,width,height]);

range1=FD_rule(record2_p1(:,2));
range2=FD_rule(record2_p2(:,2));
range3=FD_rule(record2_p3(:,2));
bin_width1 = range1(2) - range1(1);
bin_width2 = range2(2) - range2(1);
bin_width3 = range3(2) - range3(1);

[x1,y1] = hist(record2_p1(:,2),range1); % 2: max frequency
[x2,y2] = hist(record2_p2(:,2),range2); % 2: max frequency
[x3,y3] = hist(record2_p3(:,2),range2); % 2: max frequency

m = mean(record2_p1(:,2));
std1 = std(record2_p1(:,2));
hold on;fill([m-std1 , m-std1 ,m+std1,m+std1],[0,1,1,0],'r','FaceAlpha',dense_c,'Edgecolor','none')
hold on;stem(m,1,'r')
hold on;plot(y1,cumsum(x1)/(sum(x1)),'r');

m = mean(record2_p2(:,2));
std1 = std(record2_p2(:,2));
hold on;fill([m-std1 ,m-std1 , m+std1 , m+std1],[0,1,1,0],'b','FaceAlpha',dense_c,'Edgecolor','none')
hold on;stem(m,1,'b')
hold on;plot(y2,cumsum(x2)/(sum(x2)),'b');

m = mean(record2_p3(:,2));
std1 = std(record2_p3(:,2));
hold on;fill([m-std1 ,m-std1 , m+std1 , m+std1],[0,1,1,0],'g','FaceAlpha',dense_c,'Edgecolor','none')
hold on;stem(m,1,'g')
hold on;plot(y3,cumsum(x3)/(sum(x3)),'g');


xlabel('Frequency (Hz)');
ylabel('Probability');
yRange = ylim;
axis([2e3 x_limm2 yRange]);
legend({'P1(NWHI): Std range','P1(NWHI): Avrg.','P1(NWHI): CDF',...
        'P2(Pelagic): Avrg.','P2(Pelagic): Std range','P2(Pelagic): CDF',...
        'P3(MHI): Avrg.','P3(MHI): Std range','P3(MHI): CDF',...
        },'Location','northeastoutside');
box on;
title('  ','FontSize',FT_size2);


saveas(fig2,[num2str(id_p),'2_bb.jpg']);
%%
% nexttile(3,[1,1]);
fig3=figure(id_p*10+3);
set(fig3,'position',[x0,y0,width,height]);

range1=FD_rule(record2_p1(:,3));
range2=FD_rule(record2_p2(:,3));
range3=FD_rule(record2_p3(:,3));
bin_width1 = range1(2) - range1(1);
bin_width2 = range2(2) - range2(1);
bin_width3 = range3(2) - range3(1);

[x1,y1] = hist(record2_p1(:,3),range1); % 3: min frequency
[x2,y2] = hist(record2_p2(:,3),range2); % 3: min frequency
[x3,y3] = hist(record2_p3(:,3),range2); % 3: min frequency

m = mean(record2_p1(:,3));
std1 = std(record2_p1(:,3));
hold on;fill([m-std1 , m-std1 ,m+std1,m+std1],[0,1,1,0],'r','FaceAlpha',dense_c,'Edgecolor','none')
hold on;stem(m,1,'r')
plot(y1,cumsum(x1)/(sum(x1)),'r');

m = mean(record2_p2(:,3));
std1 = std(record2_p2(:,3));
hold on;fill([m-std1 ,m-std1 , m+std1 , m+std1],[0,1,1,0],'b','FaceAlpha',dense_c,'Edgecolor','none')
hold on;stem(m,1,'b')
hold on;plot(y2,cumsum(x2)/(sum(x2)),'b');

m = mean(record2_p3(:,3));
std1 = std(record2_p3(:,3));
hold on;fill([m-std1 ,m-std1 , m+std1 , m+std1],[0,1,1,0],'g','FaceAlpha',dense_c,'Edgecolor','none')
hold on;stem(m,1,'g')
hold on;plot(y3,cumsum(x3)/(sum(x3)),'g');


xlabel('Frequency (Hz)');
ylabel('Probability');
yRange = ylim;
axis([2e3 x_limm2 yRange]);
legend({'P1(NWHI): Std range','P1(NWHI): Avrg.','P1(NWHI): CDF',...
        'P2(Pelagic): Avrg.','P2(Pelagic): Std range','P2(Pelagic): CDF',...
        'P3(MHI): Avrg.','P3(MHI): Std range','P3(MHI): CDF',...
        },'Location','northeastoutside');
box on;
title('  ','FontSize',FT_size2);

saveas(fig3,[num2str(id_p),'3_bb.jpg']);
%%

% nexttile(4,[1,1]);

fig4=figure(id_p*10+4);
set(fig4,'position',[x0,y0,width,height]);

range1=FD_rule(record2_p1(:,4));
range2=FD_rule(record2_p2(:,4));
range3=FD_rule(record2_p3(:,4));
bin_width1 = range1(2) - range1(1);
bin_width2 = range2(2) - range2(1);
bin_width3 = range3(2) - range3(1);

[x1,y1] = hist(record2_p1(:,4),range1); % 4: freq band
[x2,y2] = hist(record2_p2(:,4),range2); % 4: freq band
[x3,y3] = hist(record2_p3(:,4),range2); % 4: freq band

m = mean(record2_p1(:,4));
std1 = std(record2_p1(:,4));
hold on;fill([m-std1 , m-std1 ,m+std1,m+std1],[0,1,1,0],'r','FaceAlpha',dense_c,'Edgecolor','none')
hold on;stem(m,1,'r')
hold on;plot(y1,cumsum(x1)/(sum(x1)),'r');

m = mean(record2_p2(:,4));
std1 = std(record2_p2(:,4));
hold on;fill([m-std1 ,m-std1 , m+std1 , m+std1],[0,1,1,0],'b','FaceAlpha',dense_c,'Edgecolor','none')
hold on;stem(m,1,'b')
hold on;plot(y2,cumsum(x2)/(sum(x2)),'b');

m = mean(record2_p3(:,4));
std1 = std(record2_p3(:,4));
hold on;fill([m-std1 ,m-std1 , m+std1 , m+std1],[0,1,1,0],'g','FaceAlpha',dense_c,'Edgecolor','none')
hold on;stem(m,1,'g')
hold on;plot(y3,cumsum(x3)/(sum(x3)),'g');


xlabel('Frequency (Hz)');
ylabel('Probability');
yRange = ylim;
legend({'P1(MHI)','P2(NWHI)'});
if id_p == 1
axis([0 0.75e3 yRange]);
else
axis([0 5e3 yRange]);
end

legend({'P1(NWHI): Std range','P1(NWHI): Avrg.','P1(NWHI): CDF',...
        'P2(Pelagic): Avrg.','P2(Pelagic): Std range','P2(Pelagic): CDF',...
        'P3(MHI): Avrg.','P3(MHI): Std range','P3(MHI): CDF',...
        },'Location','northeastoutside');
box on;
title('  ','FontSize',FT_size2);

saveas(fig4,[num2str(id_p),'4_bb.jpg']);
%%
% nexttile(5,[1,1]);
fig5=figure(id_p*10+5);
set(fig5,'position',[x0,y0,width,height]);

range1=FD_rule(record2_p1(:,26));
range2=FD_rule(record2_p2(:,26));
range3=FD_rule(record2_p3(:,26));

bin_width1 = range1(2) - range1(1);
bin_width2 = range2(2) - range2(1);
bin_width3 = range3(2) - range3(1);

[x1,y1] = hist(record2_p1(:,26),range1);  % 26: start frequency
[x2,y2] = hist(record2_p2(:,26),range2);  % 26: start frequency
[x3,y3] = hist(record2_p3(:,26),range3);  % 26: start frequency


m = mean(record2_p1(:,26));
std1 = std(record2_p1(:,26));
hold on;fill([m-std1 , m-std1 ,m+std1,m+std1],[0,1,1,0],'r','FaceAlpha',dense_c,'Edgecolor','none')
hold on;stem(m,1,'r')
hold on;plot(y1,cumsum(x1)/(sum(x1)),'r');

m = mean(record2_p2(:,26));
std1 = std(record2_p2(:,26));
hold on;fill([m-std1 ,m-std1 , m+std1 , m+std1],[0,1,1,0],'b','FaceAlpha',dense_c,'Edgecolor','none')
hold on;stem(m,1,'b')
hold on;plot(y2,cumsum(x2)/(sum(x2)),'b');

m = mean(record2_p3(:,26));
std1 = std(record2_p3(:,26));
hold on;fill([m-std1 ,m-std1 , m+std1 , m+std1],[0,1,1,0],'g','FaceAlpha',dense_c,'Edgecolor','none')
hold on;stem(m,1,'g')
hold on;plot(y3,cumsum(x3)/(sum(x3)),'g');

xlabel('Frequency (Hz)');
ylabel('Probability');
yRange = ylim;
axis([ 2e3 x_limm2 yRange]);
legend({'P1(NWHI): Std range','P1(NWHI): Avrg.','P1(NWHI): CDF',...
        'P2(Pelagic): Avrg.','P2(Pelagic): Std range','P2(Pelagic): CDF',...
        'P3(MHI): Avrg.','P3(MHI): Std range','P3(MHI): CDF',...
        },'Location','northeastoutside');
box on;
title('  ');
title('  ','FontSize',FT_size2);

saveas(fig5,[num2str(id_p),'5_bb.jpg']);
%%

% nexttile(6,[1,1]);
fig6=figure(id_p*10+6);
set(fig6,'position',[x0,y0,width,height]);

range1=FD_rule(record2_p1(:,27));
range2=FD_rule(record2_p2(:,27));
range3=FD_rule(record2_p3(:,27));

bin_width1 = range1(2) - range1(1);
bin_width2 = range2(2) - range2(1);
bin_width3 = range3(2) - range3(1);

[x1,y1] = hist(record2_p1(:,27),range1); % 27: end frequency
[x2,y2] = hist(record2_p2(:,27),range2); % 27: end frequency
[x3,y3] = hist(record2_p3(:,27),range2); % 27: end frequency


m = mean(record2_p1(:,27));
std1 = std(record2_p1(:,27));
hold on;fill([m-std1 , m-std1 ,m+std1,m+std1],[0,1,1,0],'r','FaceAlpha',dense_c,'Edgecolor','none')
hold on;stem(m,1,'r')
hold on;plot(y1,cumsum(x1)/(sum(x1)),'r');

m = mean(record2_p2(:,27));
std1 = std(record2_p2(:,27));
hold on;fill([m-std1 ,m-std1 , m+std1 , m+std1],[0,1,1,0],'b','FaceAlpha',dense_c,'Edgecolor','none')
hold on;stem(m,1,'b')
hold on;plot(y2,cumsum(x2)/(sum(x2)),'b');

m = mean(record2_p3(:,27));
std1 = std(record2_p3(:,27));
hold on;fill([m-std1 ,m-std1 , m+std1 , m+std1],[0,1,1,0],'g','FaceAlpha',dense_c,'Edgecolor','none')
hold on;stem(m,1,'g')
hold on;plot(y3,cumsum(x3)/(sum(x3)),'g');

xlabel('Frequency (Hz)');
ylabel('Probability');
yRange = ylim;
axis([ 2e3 x_limm2 yRange]);
legend({'P1(NWHI): Std range','P1(NWHI): Avrg.','P1(NWHI): CDF',...
        'P2(Pelagic): Avrg.','P2(Pelagic): Std range','P2(Pelagic): CDF',...
        'P3(MHI): Avrg.','P3(MHI): Std range','P3(MHI): CDF',...
        },'Location','northeastoutside');
box on;
set(gca,'FontSize',FT_size);
title('  ','FontSize',FT_size2);

saveas(fig6,[num2str(id_p),'6_bb.jpg']);
end